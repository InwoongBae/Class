#include "stdafx.h"
#include "VisualBuilding.h"
#include "Building.cpp"